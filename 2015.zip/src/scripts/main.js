/*
* @Author: 勇
* @Date:   2015-07-23 11:13:52
* @Last Modified by:   勇
* @Last Modified time: 2015-07-23 11:49:44
*/

'use strict';
document.write("123")
